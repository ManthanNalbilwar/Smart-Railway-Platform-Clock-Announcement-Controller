#ifndef TYPES_H
#define TYPES_H

typedef unsigned char        u8;
typedef signed char          s8;

typedef unsigned short       u16;
typedef signed short         s16;

typedef unsigned int         u32;
typedef signed int           s32;

typedef const char           cs8;
typedef const unsigned char  cu8;

typedef float                f32;

#endif
