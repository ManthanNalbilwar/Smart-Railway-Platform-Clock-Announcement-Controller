//scheduler.h
#ifndef SCHEDULER_H
#define SCHEDULER_H
#include "types.h"

#define STATUS_ONTIME       0
#define STATUS_APPROACHING  1
#define STATUS_DELAYED       2
#define APPROACHING_THRESHOLD  2   // minutes before arrival to start "approaching" announcement

extern u8 Line1_Scrolling_Massage[];   // train name - line1 scrolls this

u32 ToMinutes(u32 hour, u32 minute);
u32 CheckTrainStatus(u32 index);       // computes status + Line1 buffer, NO LED/LCD writes, returns status

#endif
