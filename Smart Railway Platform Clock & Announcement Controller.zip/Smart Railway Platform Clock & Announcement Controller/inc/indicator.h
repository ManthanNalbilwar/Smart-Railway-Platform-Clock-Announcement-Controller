#ifndef INDICATOR_H
#define INDICATOR_H
#include "types.h"
#define GREEN_LED   2
#define YELLOW_LED  3
#define RED_LED     4
#define BUZZER      5
void Init_LED_Buzzer(void);
void LED_GreenOn(void);
void LED_YellowOn(void);
void LED_RedOn(void);
void LED_AllOff(void);
void Buzzer_On(void);
void Buzzer_Off(void);
#endif
