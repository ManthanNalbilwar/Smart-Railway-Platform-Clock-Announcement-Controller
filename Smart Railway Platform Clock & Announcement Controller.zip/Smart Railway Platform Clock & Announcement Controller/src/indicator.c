//indicator.c
#include <lpc21xx.h>
#include "indicator.h"
void Init_LED_Buzzer(void)
{
	IODIR0|=(15<<GREEN_LED);
}
void LED_GreenOn(void)
{
	IOSET0=(1<<GREEN_LED);
}
void LED_YellowOn(void)
{
	IOSET0=(1<<YELLOW_LED);
}
void LED_RedOn(void)
{
	IOSET0=(1<<RED_LED);
}
void LED_AllOff(void)
{
	IOCLR0=(1<<GREEN_LED)|(1<<YELLOW_LED)|(1<<RED_LED);
}
void Buzzer_On(void)
{
	IOSET0=(1<<BUZZER);
}
void Buzzer_Off(void)
{
	IOCLR0=(1<<BUZZER);
}
