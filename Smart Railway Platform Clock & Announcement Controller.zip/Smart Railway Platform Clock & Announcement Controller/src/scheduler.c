//scheduler.c
#include "types.h"
#include "scheduler.h"
#include "Rtc.h"
#include "train_db.h"

// Line1 buffer: holds train NAME (line1 shows fixed "T:NO: <number>" then scrolls this name)
u8 Line1_Scrolling_Massage[30];

u32 ToMinutes(u32 hour, u32 minute)
{
	u32 TotalMin;
	TotalMin = hour*60 + minute;
	return TotalMin;
}

// Computes ONE train's status + builds its Line1 name buffer.
// Does NOT touch LEDs or LCD - caller (application.c) decides overall LED
// (based on worst status across all trains) and when/how to announce on LCD.
u32 CheckTrainStatus(u32 index)
{
	TrainInfo_t *t;
	s32 curHH, curMM, curSS;
	u32 curTotalMin, arrivalTotalMin;
	s32 diff;
	u32 status;
	u32 k;

	t = Get_Record(index);
	if(t == 0)
		return STATUS_ONTIME;

	GetRTCTimeInfo(&curHH, &curMM, &curSS);

	curTotalMin     = ToMinutes((u32)curHH, (u32)curMM);
	arrivalTotalMin = ToMinutes(t->updatedArrivalHour, t->updatedArrivalMinute);

	diff = arrivalTotalMin - curTotalMin;

	if(t->delayMinutes > 0)
		status = STATUS_DELAYED;
	else if(diff > 0 && diff <= APPROACHING_THRESHOLD)
		status = STATUS_APPROACHING;
	else
		status = STATUS_ONTIME;

	// ---- Build Line1 scrolling message: train NAME ----
	k = 0;
	while(t->trainName[k] != '\0' && k < 28)
	{
		Line1_Scrolling_Massage[k] = t->trainName[k];
		k++;
	}
	Line1_Scrolling_Massage[k] = '\0';

	return status;
}
