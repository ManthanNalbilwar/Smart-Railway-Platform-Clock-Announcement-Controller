//application.c
#include <lpc21xx.h>
#include <string.h>
#include "types.h"
#include "defines.h"
#include "delay.h"
#include "lcddefines.h"
#include "lcd.h"
#include "KPM_defines.h"
#include "kpm_v2.h"
#include "eint_sw.h"
#include "Rtc.h"
#include "train_db.h"
#include "indicator.h"
#include "scheduler.h"
#include "menu.h"

extern u8 Line1_Scrolling_Massage[];

static void Scrollline(u8 *msg,
                        u8 lcdLineCmd,
                        u8 startCol,
                        u8 windowSize,
                        u32 steps,
                        u32 stepDelayMs)
{
	u32 offset, j;
	u32 len;

	len = strlen((char*)msg);
	if(len == 0) return;

	for(offset = 0; offset < steps; offset++)
	{
		CMD_TO_LCD(lcdLineCmd + startCol);
		for(j = 0; j < windowSize; j++)
		{
			DISP_CHAR(msg[(offset+j) % len]);
		}
		delay_ms(stepDelayMs);

		if(admin_Edit_Flag == 1)
			return;
	}
}

// ---- Draws "P-<platform> <arrHH>:<arrMM> <depHH>:<depMM>" on line 2 ----
static void DrawLine2(TrainInfo_t *t)
{
	CMD_TO_LCD(GOTO_LINE2_POS0);
	DISP_STRING("P-");
	DISP_INT(t->platform);
	DISP_CHAR(' ');
	DISP_CHAR((t->updatedArrivalHour/10)+48);
	DISP_CHAR((t->updatedArrivalHour%10)+48);
	DISP_CHAR(':');
	DISP_CHAR((t->updatedArrivalMinute/10)+48);
	DISP_CHAR((t->updatedArrivalMinute%10)+48);
	DISP_CHAR(' ');
	DISP_CHAR((t->updatedDepartureHour/10)+48);
	DISP_CHAR((t->updatedDepartureHour%10)+48);
	DISP_CHAR(':');
	DISP_CHAR((t->updatedDepartureMinute/10)+48);
	DISP_CHAR((t->updatedDepartureMinute%10)+48);
}

static void ClearLine2(void)
{
	u32 i;
	CMD_TO_LCD(GOTO_LINE2_POS0);
	for(i=0; i<16; i++) DISP_CHAR(' ');
}

// ---- Shows one train's announcement:
//      Line1: "T:NO: <number>" fixed, then train NAME scrolls after it
//      Line2: "P-<platform> <arrHH>:<arrMM> <depHH>:<depMM>" - BLINKS if delayed, static otherwise
static void AnnounceTrain(u32 index, u32 status)
{
	TrainInfo_t *t = Get_Record(index);
	if(t == 0) return;

	CMD_TO_LCD(CLEAR_LCD);
	delay_ms(2);

	CMD_TO_LCD(GOTO_LINE1_POS0);
	DISP_STRING("T:NO: ");
	DISP_INT(t->trainNumber);

	if(status == STATUS_DELAYED)
	{
		u32 b;
		for(b=0; b<5; b++)
		{
			DrawLine2(t);
			delay_ms(400);
			if(admin_Edit_Flag == 1) return;
			ClearLine2();
			delay_ms(400);
			if(admin_Edit_Flag == 1) return;
		}
	}
	DrawLine2(t);   // leave it visible after blinking (or straight away if not delayed)

	Scrollline(Line1_Scrolling_Massage, GOTO_LINE1_POS0, 11, 5, 20, 300);
}

int main(void)
{
	u32 i;
	u32 status;
	u32 overall;
	u32 firstBoot;
	s32 hh, mm, ssec;
	s32 dd, mo, yy;
	s32 dow;
	u32 k;

	Init_KPM();
	Init_eint();
	firstBoot = RTC_Init();
	INIT_LCD_16X2();
	Init_LED_Buzzer();

	if(firstBoot)
	{
		FirstTimeSetup();
	}

	while(1)
	{
		// ---- Show the live clock (+day) for a few seconds ----
		for(k=0; k<6; k++)
		{
			GetRTCTimeInfo(&hh, &mm, &ssec);
			DisplayRTCTime((u32)hh, (u32)mm, (u32)ssec);

			GetRTCDay(&dow);
			DisplayRTCDay((u32)dow);

			GetRTCDateInfo(&dd, &mo, &yy);
			DisplayRTCDate((u32)dd, (u32)mo, (u32)yy);

			delay_ms(500);

			if(admin_Edit_Flag == 1) break;
		}

		if(admin_Edit_Flag == 1)
		{
			AdminMenu();
			continue;
		}

		// ---- Evaluate all trains first (silent), track worst status for LEDs ----
		overall = STATUS_ONTIME;
		for(i=0; i<GetTotalTrains(); i++)
		{
			status = CheckTrainStatus(i);
			if(status == STATUS_DELAYED)
				overall = STATUS_DELAYED;
			else if(status == STATUS_APPROACHING && overall != STATUS_DELAYED)
				overall = STATUS_APPROACHING;
		}

		LED_AllOff();
		if(overall == STATUS_ONTIME) LED_GreenOn();
		else if(overall == STATUS_APPROACHING) LED_YellowOn();
		else if(overall == STATUS_DELAYED) LED_RedOn();

		// ---- Now announce whichever trains actually need it ----
		for(i=0; i<GetTotalTrains(); i++)
		{
			status = CheckTrainStatus(i);   // recompute (also refills Line1 buffer for this train)

			if(status == STATUS_APPROACHING || status == STATUS_DELAYED)
			{
				AnnounceTrain(i, status);
			}

			if(admin_Edit_Flag == 1) break;
		}

		if(admin_Edit_Flag == 1)
		{
			AdminMenu();
		}
	}
}
