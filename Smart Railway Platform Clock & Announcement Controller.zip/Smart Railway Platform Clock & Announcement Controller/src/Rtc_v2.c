//Rtc_v2.c
#include <lpc21xx.h>
#include "Rtc.h"
#include "types.h"
#include "lcddefines.h"
#include "lcd.h"

char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};

u32 RTC_Init(void)
{
	if((CCR & RTC_ENABLE) == 0)   // RTC not already running -> genuine first boot
	{
		CCR = RTC_RESET;
		CCR = 0x00;
		PREINT  = PREINT_VAL;
		PREFRAC = PREFRAC_VAL;
		SEC = 0; MIN = 0; HOUR = 0;
		DOM = 1; MONTH = 1; YEAR = 2026;
		CCR = RTC_ENABLE;
		return 1;   // caller should now ask for time/date via keypad
	}
	return 0;   // already running (battery-backed) - leave time untouched
}
void GetRTCTimeInfo(s32 *hour,s32 *minute,s32 *second)
{
	*hour = HOUR;
	*minute = MIN;
	*second = SEC;
}
void DisplayRTCTime(u32 hour,u32 minute,u32 second)
{
	CMD_TO_LCD(GOTO_LINE1_POS0);
	DISP_CHAR(hour/10+48);
	DISP_CHAR(hour%10+48);
	DISP_CHAR(':');
	DISP_CHAR(minute/10+48);
	DISP_CHAR(minute%10+48);
	DISP_CHAR(':');
	DISP_CHAR(second/10+48);
	DISP_CHAR(second%10+48);
}
void GetRTCDateInfo(s32 *date,s32 *month,s32 *year)
{
	*date = DOM;
	*month = MONTH;
	*year = YEAR;
}
void DisplayRTCDate(u32 date,u32 month,u32 year)
{
	CMD_TO_LCD(GOTO_LINE2_POS0);
	DISP_CHAR(date/10+48);
	DISP_CHAR(date%10+48);
	DISP_CHAR('/');
	DISP_CHAR(month/10+48);
	DISP_CHAR(month%10+48);
	DISP_CHAR('/');
	DISP_INT(year);
}
void SetRTCTimeInfo(u32 hour,u32 minute,u32 second)
{
	HOUR = hour;
	MIN = minute;
	SEC = second;
}
void SetRTCDateInfo(u32 date,u32 month,u32 year)
{
	DOM = date;
	MONTH = month;
	YEAR = year;
}
void GetRTCDay(s32 *dow)
{
	*dow = DOW;
}
void DisplayRTCDay(u32 day)
{
	CMD_TO_LCD(GOTO_LINE1_POS0 + 10);
	DISP_STRING(week[day]);
}
void SetRTCDay(u32 dow)
{
	DOW = dow;
}
