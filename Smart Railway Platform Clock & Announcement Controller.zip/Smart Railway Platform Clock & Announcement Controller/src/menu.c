//menu.c
#include "types.h"
#include "defines.h"
#include "kpm_v2.h"
#include "KPM_defines.h"
#include "lcd.h"
#include "lcddefines.h"
#include "Rtc.h"
#include "train_db.h"
#include "eint_sw.h"
#include "menu.h"
#include "delay.h"

// ---- Reads digits with LIVE ECHO on LCD line2, supports backspace ('D') ----
// Terminator key ('#','*','C', etc.) is returned via *termKey.
// If the user presses the terminator with NO digits typed, defaultVal is returned unchanged.
static u32 InputField(s8 *prompt, u32 defaultVal, u8 *termKey)
{
	u8 buf[7];
	u8 idx = 0;
	u8 key;
	u32 i;
	u32 result;

	CMD_TO_LCD(CLEAR_LCD);
	delay_ms(2);
	CMD_TO_LCD(GOTO_LINE1_POS0);
	DISP_STRING(prompt);
	CMD_TO_LCD(GOTO_LINE2_POS0);

	while(1)
	{
		key = keyscan();

		if(key >= '0' && key <= '9' && idx < 6)
		{
			buf[idx++] = key;
			DISP_CHAR(key);          // echo digit on LCD
		}
		else if(key == 'D')          // backspace
		{
			if(idx > 0)
			{
				idx--;
				CMD_TO_LCD(GOTO_LINE2_POS0);
				for(i=0; i<16; i++) DISP_CHAR(' ');   // clear line2
				CMD_TO_LCD(GOTO_LINE2_POS0);
				for(i=0; i<idx; i++) DISP_CHAR(buf[i]);  // redraw remaining digits
			}
		}
		else
		{
			*termKey = key;   // '#', '*', 'C', or anything else - caller decides meaning
			break;
		}
	}

	if(idx == 0)
		return defaultVal;   // nothing typed - keep old/current value

	result = 0;
	for(i=0; i<idx; i++)
		result = result*10 + (buf[i]-48);

	return result;
}

void AdminMenu(void)
{
	u8 choice;
	u8 termKey;

	CMD_TO_LCD(CLEAR_LCD);
	delay_ms(2);
	CMD_TO_LCD(GOTO_LINE1_POS0);
	DISP_STRING("Enter The Choice");
	CMD_TO_LCD(GOTO_LINE2_POS0);
	DISP_STRING("A:EdtTm B:RschT");

	choice = keyscan();

	if(choice == 'A')
	{
		s32 curHH, curMM, curSS;
		s32 curDD, curMO, curYY;
		u32 hh, mm, ss, DD, MO, YYYY;
		u8  cancelled = 0;
		u8  doneEarly = 0;

		// ---- Pre-fill defaults with CURRENT RTC values (unedited fields keep old value) ----
		GetRTCTimeInfo(&curHH, &curMM, &curSS);
		GetRTCDateInfo(&curDD, &curMO, &curYY);
		hh = (u32)curHH; mm = (u32)curMM; ss = (u32)curSS;
		DD = (u32)curDD; MO = (u32)curMO; YYYY = (u32)curYY;

		// ---- HH ----
		hh = InputField("HH: #/*/C", hh, &termKey);
		if(termKey == 'C') cancelled = 1;
		else if(termKey == '*') doneEarly = 1;

		// ---- MM ----
		if(!cancelled && !doneEarly)
		{
			mm = InputField("MM: #/*/C", mm, &termKey);
			if(termKey == 'C') cancelled = 1;
			else if(termKey == '*') doneEarly = 1;
		}

		// ---- SS ----
		if(!cancelled && !doneEarly)
		{
			ss = InputField("SS: #/*/C", ss, &termKey);
			if(termKey == 'C') cancelled = 1;
			else if(termKey == '*') doneEarly = 1;
		}

		CMD_TO_LCD(CLEAR_LCD); delay_ms(2);
		CMD_TO_LCD(GOTO_LINE1_POS0);
		if(cancelled)
		{
			DISP_STRING("Time Cancelled");
		}
		else
		{
			SetRTCTimeInfo(hh, mm, ss);
			DISP_STRING("Time Updated!");
		}
		delay_ms(1000);

		// ==== DATE EDIT only if time wasn't cancelled/finished-early ====
		if(!cancelled && !doneEarly)
		{
			cancelled = 0;
			doneEarly = 0;

			DD = InputField("DD: #/*/C", DD, &termKey);
			if(termKey == 'C') cancelled = 1;
			else if(termKey == '*') doneEarly = 1;

			if(!cancelled && !doneEarly)
			{
				MO = InputField("MO: #/*/C", MO, &termKey);
				if(termKey == 'C') cancelled = 1;
				else if(termKey == '*') doneEarly = 1;
			}

			if(!cancelled && !doneEarly)
			{
				YYYY = InputField("YYYY: #/*/C", YYYY, &termKey);
				if(termKey == 'C') cancelled = 1;
				else if(termKey == '*') doneEarly = 1;
			}

			CMD_TO_LCD(CLEAR_LCD); delay_ms(2);
			CMD_TO_LCD(GOTO_LINE1_POS0);
			if(cancelled)
			{
				DISP_STRING("Date Cancelled");
			}
			else
			{
				SetRTCDateInfo(DD, MO, YYYY);
				DISP_STRING("Date Updated!");
			}
			delay_ms(1000);
		}
	}
	else if(choice == 'B')
	{
		u32 trainNo, idx;
		TrainInfo_t *t;
		u32 platform, delayMin, arrHH, arrMM, depHH, depMM;
		u8  cancelled = 0;
		u8  doneEarly = 0;

		CMD_TO_LCD(CLEAR_LCD);
		delay_ms(2);
		CMD_TO_LCD(GOTO_LINE1_POS0);
		DISP_STRING("SELECT TRAIN NO");
		CMD_TO_LCD(GOTO_LINE2_POS0);
		DISP_STRING("1,2 or 3");

		trainNo = keyscan() - '0';
		idx = trainNo - 1;

		if(trainNo < 1 || trainNo > GetTotalTrains())
		{
			CMD_TO_LCD(CLEAR_LCD); delay_ms(2);
			CMD_TO_LCD(GOTO_LINE1_POS0);
			DISP_STRING("Invalid Train No");
			delay_ms(1000);
		}
		else
		{
			t = Get_Record(idx);

			// ---- Pre-fill defaults with CURRENT train values ----
			platform = t->platform;
			delayMin = t->delayMinutes;
			arrHH = t->updatedArrivalHour;
			arrMM = t->updatedArrivalMinute;
			depHH = t->updatedDepartureHour;
			depMM = t->updatedDepartureMinute;

			platform = InputField("Platform: #/*/C", platform, &termKey);
			if(termKey == 'C') cancelled = 1;
			else if(termKey == '*') doneEarly = 1;

			if(!cancelled && !doneEarly)
			{
				delayMin = InputField("Delay-min: #/*/C", delayMin, &termKey);
				if(termKey == 'C') cancelled = 1;
				else if(termKey == '*') doneEarly = 1;
			}
			if(!cancelled && !doneEarly)
			{
				arrHH = InputField("Arr HH: #/*/C", arrHH, &termKey);
				if(termKey == 'C') cancelled = 1;
				else if(termKey == '*') doneEarly = 1;
			}
			if(!cancelled && !doneEarly)
			{
				arrMM = InputField("Arr MM: #/*/C", arrMM, &termKey);
				if(termKey == 'C') cancelled = 1;
				else if(termKey == '*') doneEarly = 1;
			}
			if(!cancelled && !doneEarly)
			{
				depHH = InputField("Dep HH: #/*/C", depHH, &termKey);
				if(termKey == 'C') cancelled = 1;
				else if(termKey == '*') doneEarly = 1;
			}
			if(!cancelled && !doneEarly)
			{
				depMM = InputField("Dep MM: #/*/C", depMM, &termKey);
				if(termKey == 'C') cancelled = 1;
				else if(termKey == '*') doneEarly = 1;
			}

			CMD_TO_LCD(CLEAR_LCD); delay_ms(2);
			CMD_TO_LCD(GOTO_LINE1_POS0);
			if(cancelled)
			{
				DISP_STRING("Train Cancelled");
			}
			else
			{
				Update_Platform(idx, platform);
				Set_Train_Delay(idx, delayMin);
				Updated_Train_Arrival(idx, arrHH, arrMM);
				Updated_Train_Departure(idx, depHH, depMM);
				DISP_STRING("Train Updated!");
			}
			delay_ms(1000);
		}
	}

	// ---- Back to normal mode ----
	CMD_TO_LCD(CLEAR_LCD);
	delay_ms(2);
	admin_Edit_Flag = 0;
}

// ==== Called ONCE on power-up, only if RTC_Init() reports first-time boot ====
void FirstTimeSetup(void)
{
	u32 hh, mm, ss, dow, DD, MO, YYYY;
	u8 termKey;

	CMD_TO_LCD(CLEAR_LCD); delay_ms(2);
	CMD_TO_LCD(GOTO_LINE1_POS0);
	DISP_STRING("FIRST TIME SETUP");
	delay_ms(1000);

	hh   = InputField("HH: (# next)", 0, &termKey);
	mm   = InputField("MM: (# next)", 0, &termKey);
	ss   = InputField("SS: (# next)", 0, &termKey);
	SetRTCTimeInfo(hh, mm, ss);

	dow  = InputField("Day(0=Sun6=Sat)", 0, &termKey);
	SetRTCDay(dow);

	DD   = InputField("DD: (# next)", 1, &termKey);
	MO   = InputField("MO: (# next)", 1, &termKey);
	YYYY = InputField("YYYY:(# next)", 2026, &termKey);
	SetRTCDateInfo(DD, MO, YYYY);

	CMD_TO_LCD(CLEAR_LCD); delay_ms(2);
	CMD_TO_LCD(GOTO_LINE1_POS0);
	DISP_STRING("Setup Done!");
	delay_ms(1000);
	CMD_TO_LCD(CLEAR_LCD);
	delay_ms(2);
}
